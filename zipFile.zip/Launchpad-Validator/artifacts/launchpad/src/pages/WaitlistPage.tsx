import { useEffect } from "react";
import { Link } from "wouter";
import { Rocket } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const waitlistSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  role: z.enum(["believer", "creator", "both"], {
    required_error: "Please select how you want to join.",
  }),
  city: z.string().optional(),
});

type WaitlistFormValues = z.infer<typeof waitlistSchema>;

export function WaitlistPage() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    document.title = "Join Waitlist | Launchpad";
  }, []);

  const form = useForm<WaitlistFormValues>({
    resolver: zodResolver(waitlistSchema),
    defaultValues: {
      name: "",
      email: "",
      role: undefined,
      city: "",
    },
  });

  const onSubmit = (data: WaitlistFormValues) => {
    const existing = JSON.parse(localStorage.getItem('launchpad_waitlist') || '[]');
    existing.push({ ...data, timestamp: new Date().toISOString() });
    localStorage.setItem('launchpad_waitlist', JSON.stringify(existing));
    
    setIsSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <nav className="w-full border-b border-border/40 py-4">
        <div className="container mx-auto px-4 flex justify-center">
          <Link href="/" className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" />
            <span className="font-bold text-2xl tracking-tight">Launchpad</span>
          </Link>
        </div>
      </nav>

      <div className="flex-grow flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-lg bg-card rounded-3xl border border-border shadow-xl overflow-hidden">
          <AnimatePresence mode="wait">
            {!isSubmitted ? (
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="p-8 sm:p-12"
              >
                <div className="text-center mb-10">
                  <h1 className="text-3xl font-extrabold tracking-tight mb-3">Be among the first.</h1>
                  <p className="text-lg text-muted-foreground">
                    Launchpad is opening soon. Tell us who you are, and you'll be invited to the room.
                  </p>
                </div>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Arjun Reddy" {...field} className="h-12 rounded-xl text-base" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Email</FormLabel>
                          <FormControl>
                            <Input placeholder="arjun@example.com" {...field} className="h-12 rounded-xl text-base" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem className="space-y-4">
                          <FormLabel className="text-base font-semibold">I'm here as a...</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2 bg-[#F8F9FA] p-4 rounded-xl border border-border"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0 p-2 rounded-lg hover:bg-white transition-colors">
                                <FormControl>
                                  <RadioGroupItem value="believer" className="w-5 h-5" />
                                </FormControl>
                                <FormLabel className="font-medium text-base cursor-pointer">Believer (I want to support ideas)</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0 p-2 rounded-lg hover:bg-white transition-colors">
                                <FormControl>
                                  <RadioGroupItem value="creator" className="w-5 h-5" />
                                </FormControl>
                                <FormLabel className="font-medium text-base cursor-pointer">Creator (I have an idea to build)</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0 p-2 rounded-lg hover:bg-white transition-colors">
                                <FormControl>
                                  <RadioGroupItem value="both" className="w-5 h-5" />
                                </FormControl>
                                <FormLabel className="font-medium text-base cursor-pointer">Both</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">City <span className="text-muted-foreground font-normal">(Optional)</span></FormLabel>
                          <FormControl>
                            <Input placeholder="Bengaluru" {...field} className="h-12 rounded-xl text-base" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" size="lg" className="w-full h-14 rounded-xl text-lg font-bold mt-4 shadow-md hover:shadow-lg transition-all">
                      Join the Waitlist
                    </Button>
                  </form>
                </Form>
              </motion.div>
            ) : (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-12 sm:p-16 flex flex-col items-center justify-center text-center space-y-6 h-[600px]"
              >
                <div className="h-24 w-24 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                  <CheckCircle2 className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-4xl font-extrabold tracking-tight">You're in.</h3>
                <p className="text-xl text-muted-foreground max-w-xs">
                  We'll reach out when Launchpad opens its doors — and you'll be among the first.
                </p>
                <Link href="/">
                  <Button variant="outline" size="lg" className="mt-8 rounded-xl h-12 px-8">
                    Back to Homepage
                  </Button>
                </Link>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
