import { useState, useMemo, useEffect } from "react";
import { useSearch } from "wouter";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { CategoryNav } from "@/components/CategoryNav";
import { ProjectCard } from "@/components/ProjectCard";
import { projects, Category, Project } from "@/data/projects";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { motion } from "framer-motion";

type SortOption = 'trending' | 'newest' | 'ending-soon';

function calculateTrendingScore(p: Project) {
  // Simple heuristic: lots of believers relative to days active
  return p.believersCount; 
}

export function ExplorePage() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const categoryParam = searchParams.get('category') as Category | null;

  const initialQ = searchParams.get('q') ?? "";
  const [searchQuery, setSearchQuery] = useState(initialQ);
  const [debouncedQuery, setDebouncedQuery] = useState(initialQ);
  const [sortOption, setSortOption] = useState<SortOption>('trending');

  useEffect(() => {
    document.title = "Explore Projects | Launchpad";
  }, []);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const filteredProjects = useMemo(() => {
    let result = [...projects];

    // 1. Filter by category
    if (categoryParam) {
      result = result.filter(p => p.category === categoryParam);
    }

    // 2. Filter by search query
    if (debouncedQuery) {
      const lowerQ = debouncedQuery.toLowerCase();
      result = result.filter(p => 
        p.title.toLowerCase().includes(lowerQ) ||
        p.tagline.toLowerCase().includes(lowerQ) ||
        p.tags.some(t => t.toLowerCase().includes(lowerQ))
      );
    }

    // 3. Sort
    result.sort((a, b) => {
      switch (sortOption) {
        case 'trending':
          return calculateTrendingScore(b) - calculateTrendingScore(a);
        case 'newest':
          // In mock data we don't have created date, so we'll use daysLeft descending as proxy
          return b.daysLeft - a.daysLeft;
        case 'ending-soon':
          // Only live projects, shortest days left first. Made real at the bottom.
          if (a.status === 'made-real' && b.status === 'made-real') return 0;
          if (a.status === 'made-real') return 1;
          if (b.status === 'made-real') return -1;
          return a.daysLeft - b.daysLeft;
        default:
          return 0;
      }
    });

    return result;
  }, [categoryParam, debouncedQuery, sortOption]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-grow">
        <div className="bg-[#F8F9FA] pt-12 pb-8">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight text-foreground">
              What's being built right now
            </h1>
          </div>
        </div>

        <CategoryNav />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-10">
            <div className="relative w-full sm:max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search ideas, creators, or tags..." 
                className="pl-10 h-12 bg-white rounded-xl shadow-sm border-border/60 text-base"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="w-full sm:w-auto">
              <Select value={sortOption} onValueChange={(val) => setSortOption(val as SortOption)}>
                <SelectTrigger className="w-full sm:w-[200px] h-12 bg-white rounded-xl shadow-sm border-border/60">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="trending">Trending</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="ending-soon">Ending Soon</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {filteredProjects.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project, index) => (
                <ProjectCard key={project.slug} project={project} index={index % 12} />
              ))}
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="text-center py-24"
            >
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="h-10 w-10 text-muted-foreground opacity-50" />
              </div>
              <h3 className="text-2xl font-bold mb-2">No projects found</h3>
              <p className="text-muted-foreground text-lg">Try adjusting your filters or search query.</p>
            </motion.div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
