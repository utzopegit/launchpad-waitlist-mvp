import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { CategoryNav } from "@/components/CategoryNav";
import { ProjectCard } from "@/components/ProjectCard";
import { AnimatedCounter } from "@/components/AnimatedCounter";
import { projects } from "@/data/projects";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useWaitlist } from "@/contexts/WaitlistContext";
import { Link, useLocation } from "wouter";
import { Sparkles, Users, Zap, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { ProgressBar } from "@/components/ProgressBar";
import { formatINR } from "@/lib/utils";
import { ShieldCheck } from "lucide-react";
import { Input } from "@/components/ui/input";

export function HomePage() {
  const { openWaitlist } = useWaitlist();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    document.title = "Launchpad | Bring Ideas to Life. Together.";
  }, []);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/explore?q=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      setLocation("/explore");
    }
  }

  const spotlight = projects
    .filter(p => p.category === "Consumer Products")
    .reduce((a, b) => b.believersCount > a.believersCount ? b : a);
  const spotlightPct = Math.min(100, Math.round((spotlight.fuelledAmountInr / spotlight.goalAmountInr) * 100));

  const gridProjects = projects
    .filter(p => p.slug !== spotlight.slug)
    .sort((a, b) => b.believersCount - a.believersCount)
    .slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-grow">

        {/* ── Hero ── */}
        <section className="relative overflow-hidden bg-white">
          {/* Left graffiti cluster */}
          <div className="absolute left-0 top-0 h-full w-40 md:w-56 pointer-events-none select-none" aria-hidden>
            <svg viewBox="0 0 220 320" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute inset-0 w-full h-full opacity-70">
              {/* Jagged star */}
              <path d="M38 28 L44 44 L60 38 L48 52 L62 64 L44 60 L40 78 L32 62 L16 68 L26 52 L12 40 L30 44 Z" fill="#FBBF24" opacity="0.7"/>
              {/* Squiggly line */}
              <path d="M10 110 Q25 100 35 115 Q48 130 60 118 Q72 106 80 122" stroke="#F472B6" strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.6"/>
              {/* Block letter */}
              <rect x="18" y="150" width="28" height="28" rx="4" fill="#70DEFE" opacity="0.35"/>
              <rect x="52" y="160" width="20" height="20" rx="4" fill="#34D399" opacity="0.4"/>
              {/* Arrow doodle */}
              <path d="M30 210 L55 210 M45 200 L55 210 L45 220" stroke="#A78BFA" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.65"/>
              {/* Dots scatter */}
              <circle cx="72" cy="80" r="5" fill="#FB923C" opacity="0.5"/>
              <circle cx="20" cy="88" r="3.5" fill="#70DEFE" opacity="0.5"/>
              <circle cx="58" cy="240" r="4" fill="#FBBF24" opacity="0.5"/>
              <circle cx="14" cy="260" r="6" fill="#F472B6" opacity="0.35"/>
              {/* Small star */}
              <path d="M75 170 L78 180 L88 180 L80 186 L83 196 L75 190 L67 196 L70 186 L62 180 L72 180 Z" fill="#34D399" opacity="0.5"/>
              {/* Spray dots */}
              <circle cx="90" cy="40" r="2" fill="#A78BFA" opacity="0.4"/>
              <circle cx="96" cy="50" r="1.5" fill="#A78BFA" opacity="0.3"/>
              <circle cx="84" cy="48" r="1.5" fill="#A78BFA" opacity="0.35"/>
            </svg>
          </div>

          {/* Right graffiti cluster */}
          <div className="absolute right-0 top-0 h-full w-40 md:w-56 pointer-events-none select-none" aria-hidden>
            <svg viewBox="0 0 220 320" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute inset-0 w-full h-full opacity-70">
              {/* Burst */}
              <path d="M180 35 L186 25 L190 37 L202 32 L196 44 L208 48 L196 52 L202 64 L190 59 L186 71 L180 59 L168 64 L174 52 L162 48 L174 44 L168 32 L180 37 Z" fill="#F472B6" opacity="0.55"/>
              {/* Squiggle */}
              <path d="M140 95 Q155 82 165 100 Q178 118 190 105 Q202 92 210 108" stroke="#FBBF24" strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.55"/>
              {/* Block */}
              <rect x="172" y="148" width="24" height="24" rx="4" fill="#FB923C" opacity="0.4"/>
              <rect x="140" y="158" width="18" height="18" rx="3" fill="#70DEFE" opacity="0.35"/>
              {/* Lightning bolt */}
              <path d="M198 200 L188 216 L196 216 L184 236 L200 218 L192 218 Z" fill="#FBBF24" opacity="0.6"/>
              {/* Dots */}
              <circle cx="148" cy="72" r="5" fill="#34D399" opacity="0.5"/>
              <circle cx="210" cy="80" r="3.5" fill="#F472B6" opacity="0.45"/>
              <circle cx="158" cy="250" r="5" fill="#A78BFA" opacity="0.45"/>
              <circle cx="205" cy="265" r="4" fill="#70DEFE" opacity="0.4"/>
              {/* Small star */}
              <path d="M145 192 L148 202 L158 202 L150 208 L153 218 L145 212 L137 218 L140 208 L132 202 L142 202 Z" fill="#FB923C" opacity="0.5"/>
              {/* Spray */}
              <circle cx="128" cy="38" r="2" fill="#34D399" opacity="0.35"/>
              <circle cx="122" cy="48" r="1.5" fill="#34D399" opacity="0.3"/>
              <circle cx="134" cy="46" r="1.5" fill="#34D399" opacity="0.35"/>
            </svg>
          </div>

          <motion.div
            className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8 relative z-10 text-center"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-[44px] font-extrabold tracking-tight leading-[1.1] mb-3">
              Bring Ideas to Life.{" "}
              <span
                className="text-primary"
                style={{ WebkitTextStroke: "2px #000", paintOrder: "stroke fill" } as React.CSSProperties}
              >Together.</span>
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground max-w-xl mx-auto leading-relaxed">
              India's space for creators, innovators, and dreamers —{" "}
              <strong className="text-foreground">and the people who believe in them.</strong>
            </p>
          </motion.div>
        </section>

        {/* ── Search bar — above categories ── */}
        <div className="bg-white border-b border-border/20 py-3">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <form onSubmit={handleSearch} className="flex items-center gap-2 max-w-lg mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input
                  placeholder="Search ideas, creators, tags..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10 h-10 rounded-full bg-[#F8F9FA] border-border/40 text-sm focus-visible:ring-primary"
                />
              </div>
              <Button type="submit" size="sm" className="rounded-full h-10 px-5 text-sm font-semibold shrink-0">
                Search
              </Button>
            </form>
          </div>
        </div>

        {/* ── Category Nav — sticky below hero ── */}
        <CategoryNav />

        {/* ── Featured Section ── */}
        <section className="py-10 md:py-14 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">

              {/* Left — big featured project (white card style) */}
              <motion.div
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <p className="text-xs font-bold tracking-[0.3em] uppercase text-primary mb-2" style={{ WebkitTextStroke: "1px #000", paintOrder: "stroke fill" } as React.CSSProperties}>Featured Project</p>
                <Link href={`/projects/${spotlight.slug}`}>
                  <div className="group bg-card rounded-2xl border border-card-border overflow-hidden shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-pointer">

                    {/* Cover image — tall */}
                    <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
                      <img
                        src={spotlight.coverImageUrl}
                        alt={spotlight.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      {/* Category badge */}
                      <div className="absolute bottom-3 left-3">
                        <span className="text-[10px] font-semibold uppercase tracking-wider bg-background/90 backdrop-blur-sm text-foreground px-2.5 py-1 rounded-full shadow-sm">
                          {spotlight.category}
                        </span>
                      </div>
                      {/* Trust score */}
                      {spotlight.trustScore !== null && (
                        <div className="absolute top-3 right-3 flex items-center gap-1 bg-green-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow">
                          <ShieldCheck className="h-3 w-3" />
                          Trust {spotlight.trustScore}
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="p-5">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <span className="text-[10px] text-muted-foreground">{spotlight.location}</span>
                      </div>
                      <h3 className="text-xl font-bold mb-1 group-hover:text-primary transition-colors">
                        {spotlight.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">{spotlight.tagline}</p>

                      <div className="space-y-1.5 mb-4">
                        <ProgressBar fuelledAmountInr={spotlight.fuelledAmountInr} goalAmountInr={spotlight.goalAmountInr} />
                        <div className="flex justify-between text-sm font-medium">
                          <span className="text-primary">{formatINR(spotlight.fuelledAmountInr)}</span>
                          <span className="text-muted-foreground">{spotlightPct}%</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-sm border-t border-border pt-3">
                        <span className="font-semibold">{spotlight.believersCount.toLocaleString()} believers</span>
                        <span className="text-muted-foreground">{spotlight.daysLeft} days left</span>
                        <span className="text-muted-foreground">of {formatINR(spotlight.goalAmountInr)}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>

              {/* Right — 2×2 grid */}
              <motion.div
                initial={{ opacity: 0, x: 16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="flex flex-col h-full"
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-bold tracking-[0.3em] uppercase text-primary" style={{ WebkitTextStroke: "1px #000", paintOrder: "stroke fill" } as React.CSSProperties}>We found this awesome</p>
                  <Link href="/explore" className="group hidden sm:flex items-center text-xs text-muted-foreground hover:text-primary transition-colors">
                    See all →
                  </Link>
                </div>
                <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-4">
                  {gridProjects.map((project, i) => (
                    <ProjectCard key={project.slug} project={project} index={i} compact />
                  ))}
                </div>
              </motion.div>

            </div>

            <div className="mt-6 text-center sm:hidden">
              <Link href="/explore" className="text-sm text-primary font-medium">See all projects →</Link>
            </div>
          </div>
        </section>

        {/* ── How it Works ── */}
        <section className="bg-white py-16 md:py-20 overflow-hidden">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-xl mx-auto mb-12">
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-3">How Launchpad Works</h2>
              <p className="text-muted-foreground text-sm">Not about transactions. About making things happen together.</p>
            </div>

            <div className="relative max-w-4xl mx-auto">
              <div className="absolute top-10 left-[12%] right-[12%] h-px bg-border/60 hidden md:block">
                <motion.div
                  className="h-full bg-primary/50"
                  initial={{ width: 0 }}
                  whileInView={{ width: "100%" }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 1.4, ease: "easeInOut" }}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-center relative z-10">
                {[
                  { icon: Sparkles, num: 1, title: "Creators share their vision", desc: "Got an idea? A project? A dream? Share it here." },
                  { icon: Users, num: 2, title: "Believers show up", desc: "People who love what you're building say: let's make this real." },
                  { icon: Zap, num: 3, title: "The idea becomes real", desc: "Together, it actually happens." },
                ].map(({ icon: Icon, num, title, desc }, i) => (
                  <motion.div
                    key={num}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.18 }}
                    className="flex flex-col items-center"
                  >
                    <div className="w-20 h-20 rounded-full bg-white shadow-sm border border-border flex items-center justify-center mb-5 relative">
                      <Icon className="h-8 w-8 text-primary" />
                      <div className="absolute -bottom-2.5 -right-2.5 w-7 h-7 rounded-full bg-[#0A0F1A] text-white flex items-center justify-center font-bold text-xs">{num}</div>
                    </div>
                    <h3 className="text-base font-bold mb-2">{title}</h3>
                    <p className="text-sm text-muted-foreground">{desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── What is Reward-Based Support ── */}
        <section className="bg-[#F8F9FA] py-14 md:py-16 border-b border-border/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
              {/* Left: Explainer text */}
              <motion.div
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <p className="text-xs font-bold tracking-[0.3em] uppercase text-primary mb-2" style={{ WebkitTextStroke: "1px #000", paintOrder: "stroke fill" } as React.CSSProperties}>What is Reward Based Crowdfunding</p>
                <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-4">
                  Not a donation.<br />Not an investment.<br />Something better.
                </h2>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                  When you believe in a project on Launchpad, you get something real in return — a reward. It could be the first product off the line, a signed copy, a behind-the-scenes experience, or your name in the credits.
                </p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  If the campaign reaches its goal, your support goes directly to making it happen. If it doesn't, nothing is charged. Zero risk. Pure belief.
                </p>
              </motion.div>

              {/* Right: 3 tiles */}
              <motion.div
                initial={{ opacity: 0, x: 16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="grid grid-cols-1 gap-4"
              >
                {[
                  { emoji: "🎁", title: "You get a reward", desc: "Early access, limited editions, credits — something meaningful, not a receipt." },
                  { emoji: "🛡️", title: "You're protected", desc: "If a campaign doesn't reach its goal, your support is fully returned. No questions." },
                  { emoji: "🤝", title: "You become part of the story", desc: "Believers aren't passive. You're part of how this thing came to life." },
                ].map(({ emoji, title, desc }, i) => (
                  <motion.div
                    key={title}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 + i * 0.1 }}
                    className="flex items-start gap-4 bg-white rounded-xl p-4 border border-border/40 shadow-sm"
                  >
                    <div className="text-2xl flex-shrink-0">{emoji}</div>
                    <div>
                      <div className="font-semibold text-sm mb-0.5">{title}</div>
                      <div className="text-xs text-muted-foreground leading-relaxed">{desc}</div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── Stats Strip ── */}
        <section className="bg-[#0A0F1A] text-white py-14">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-white/10">
              {[
                { value: 8.5, label: "fuelled into ideas so far", prefix: "₹", suffix: "L+", format: (v: number) => v.toFixed(1), duration: 2 },
                { value: 20, label: "campaigns live right now", prefix: "", suffix: "+", format: (v: number) => Math.round(v).toString(), duration: 2 },
                { value: 340, label: "believers and counting", prefix: "", suffix: "+", format: (v: number) => Math.round(v).toString(), duration: 2.5 },
              ].map(({ value, label, prefix, suffix, format, duration }, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex flex-col items-center pt-6 md:pt-0"
                >
                  <div className="text-4xl md:text-5xl font-bold mb-1.5 tracking-tight">
                    {prefix}<AnimatedCounter value={value} format={format} duration={duration} />{suffix}
                  </div>
                  <div className="text-white/50 text-xs font-semibold tracking-widest uppercase">{label}</div>
                </motion.div>
              ))}
            </div>
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-center text-white/60 text-sm mt-10"
            >
              We're just getting started. Help us reach our first 1,000 believers.
            </motion.p>
          </div>
        </section>

        {/* ── Community Stories ── */}
        <section className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-10 text-center">Stories from the room</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {[
                {
                  story: 'Priya had been designing sustainable sneakers in her notebook for 3 years. Then she brought them here. In 12 days, 342 believers said "we want this." Now, KADAM is going into production.',
                  img: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=100&auto=format&fit=crop&q=80",
                  name: "KADAM Sneakers", stat: "342 Believers", bg: "bg-[#F8F9FA]",
                },
                {
                  story: "The Ghar Hub team had the tech, but no marketing budget. They launched here hoping for 50 early adopters. They got 487 — and proved Indian apartments actually needed this device.",
                  img: "https://images.unsplash.com/photo-1558002038-1055907df827?w=100&auto=format&fit=crop&q=80",
                  name: "Ghar Smart Hub", stat: "487 Believers", bg: "bg-[#F1F3F5]",
                },
              ].map(({ story, img, name, stat, bg }, i) => (
                <motion.div
                  key={name}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.12 }}
                  className={`${bg} rounded-2xl p-7 md:p-9 relative overflow-hidden`}
                >
                  <div className="text-5xl text-primary/15 absolute top-3 left-5 font-serif leading-none select-none">"</div>
                  <div className="relative z-10 flex flex-col h-full">
                    <p className="text-base font-medium leading-relaxed mb-6 flex-grow">{story}</p>
                    <div className="flex items-center gap-3">
                      <img src={img} alt={name} className="w-10 h-10 rounded-full object-cover" />
                      <div>
                        <div className="font-bold text-sm">{name}</div>
                        <div className="text-xs text-muted-foreground">{stat}</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Closing CTA ── */}
        <section className="bg-[#0A0F1A] text-white py-20 md:py-28 relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/8" style={{ mixBlendMode: "screen" }} />
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-2xl">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              Your idea deserves<br />to exist.
            </h2>
            <p className="text-base text-white/60 mb-9 leading-relaxed">
              Whatever you're building — or whatever you want to see built —{" "}
              <strong className="text-white/80">Launchpad is where it starts.</strong>
            </p>
            <Button
              size="lg"
              onClick={openWaitlist}
              className="h-13 px-10 rounded-full font-semibold bg-primary text-primary-foreground hover:bg-primary/90 text-base shadow-lg hover:shadow-xl transition-all"
            >
              Join the waitlist
            </Button>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
