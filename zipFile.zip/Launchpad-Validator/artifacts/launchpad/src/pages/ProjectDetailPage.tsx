import { useEffect } from "react";
import { useParams } from "wouter";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { projects } from "@/data/projects";
import NotFound from "./not-found";
import { motion } from "framer-motion";
import { ProgressBar } from "@/components/ProgressBar";
import { TrustScore } from "@/components/TrustScore";
import { formatINR } from "@/lib/utils";
import { useWaitlist } from "@/contexts/WaitlistContext";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MapPin, ShieldCheck, Clock, Users } from "lucide-react";

export function ProjectDetailPage() {
  const params = useParams();
  const { openWaitlist } = useWaitlist();

  const project = projects.find(p => p.slug === params.slug);

  useEffect(() => {
    if (project) {
      document.title = `${project.title} | Launchpad`;
      window.scrollTo(0, 0);
    }
  }, [project]);

  if (!project) return <NotFound />;

  // Actual percentage — NOT capped at 100
  const percentage = Math.round((project.fuelledAmountInr / project.goalAmountInr) * 100);
  const isUrgent = project.status === "live" && project.daysLeft <= 5;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative w-full h-[50vh] md:h-[60vh] bg-black">
          <div className="absolute inset-0">
            <img
              src={project.coverImageUrl}
              alt={project.title}
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
          </div>

          <div className="absolute bottom-0 w-full pb-10">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-white">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="max-w-4xl"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Badge variant="secondary" className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-md border-none">
                    {project.category}
                  </Badge>
                  <div className="flex items-center text-sm font-medium text-white/80">
                    <MapPin className="w-4 h-4 mr-1" /> {project.location}
                  </div>
                </div>

                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-4 leading-tight">
                  {project.title}
                </h1>
                <p className="text-xl md:text-2xl text-white/90 max-w-3xl font-light">
                  {project.tagline}
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Content Layout */}
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">

              {/* Left Column - Main Content */}
              <div className="lg:col-span-8 order-2 lg:order-1">
                <Tabs defaultValue="story" className="w-full">
                  <TabsList className="w-full justify-start h-14 bg-transparent border-b border-border rounded-none p-0 overflow-x-auto overflow-y-hidden space-x-6 flex-nowrap hide-scrollbar">
                    <TabsTrigger value="story" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-14 px-2 font-semibold text-base">Story</TabsTrigger>
                    <TabsTrigger value="updates" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-14 px-2 font-semibold text-base">Updates <Badge variant="secondary" className="ml-2 bg-muted">3</Badge></TabsTrigger>
                    <TabsTrigger value="community" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-14 px-2 font-semibold text-base">Community</TabsTrigger>
                    <TabsTrigger value="qa" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-14 px-2 font-semibold text-base">Q&A</TabsTrigger>
                  </TabsList>

                  <div className="mt-8">
                    <TabsContent value="story" className="prose prose-lg max-w-none prose-headings:font-bold prose-headings:tracking-tight prose-p:text-muted-foreground prose-p:leading-relaxed">
                      <p className="text-xl leading-relaxed text-foreground font-medium mb-8">
                        {project.story}
                      </p>

                      <div className="my-10 bg-[#F8F9FA] p-8 rounded-2xl">
                        <h3 className="text-xl font-bold mt-0 mb-4">The Vision</h3>
                        <p>We believe in building things that don't just exist, but thrive in the context they were meant for. The journey so far has been incredibly rewarding, but to make this real, we need believers who see the potential of this idea as clearly as we do.</p>
                      </div>

                      <h3 className="text-2xl font-bold mt-12 mb-4">Risks & Challenges</h3>
                      <p>{project.risks}</p>
                      <p>Transparency is our core value. If delays happen, you will be the first to know, with a clear explanation and a revised timeline.</p>
                    </TabsContent>

                    <TabsContent value="updates">
                      <div className="py-12 text-center text-muted-foreground">
                        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                          <Clock className="w-8 h-8 opacity-50" />
                        </div>
                        <h3 className="text-xl font-bold text-foreground mb-2">Updates coming soon</h3>
                        <p>The creator hasn't posted any updates yet.</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="community">
                      <div className="py-12 text-center text-muted-foreground">
                        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                          <Users className="w-8 h-8 opacity-50" />
                        </div>
                        <h3 className="text-xl font-bold text-foreground mb-2">{project.believersCount} Believers</h3>
                        <p>Join the community to see who else believes in this idea.</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="qa">
                      <div className="py-12 text-center text-muted-foreground">
                        <h3 className="text-xl font-bold text-foreground mb-2">Have a question?</h3>
                        <p className="mb-6">Ask the creator directly.</p>
                        <Button variant="outline" onClick={openWaitlist}>Ask a Question</Button>
                      </div>
                    </TabsContent>
                  </div>
                </Tabs>
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-4 order-1 lg:order-2">
                <div className="sticky top-24 space-y-8">

                  {/* Funding Card */}
                  <div className="bg-card border border-border shadow-md rounded-2xl p-6">
                    {project.trustScore && (
                      <TrustScore score={project.trustScore} className="mb-6" />
                    )}

                    <div className="mb-4">
                      <ProgressBar
                        fuelledAmountInr={project.fuelledAmountInr}
                        goalAmountInr={project.goalAmountInr}
                        className="h-3"
                      />
                    </div>

                    <div className="space-y-4 mb-8">
                      <div>
                        <div className="text-3xl font-bold text-primary tracking-tight">
                          {formatINR(project.fuelledAmountInr)}
                        </div>
                        <div className="text-sm text-muted-foreground font-medium uppercase tracking-wide mt-1">
                          fuelled so far · <span className="font-bold text-foreground">{percentage}%</span>
                        </div>
                      </div>

                      <div className="text-sm border-t border-border pt-4">
                        <span className="text-muted-foreground">What's needed to make this real: </span>
                        <span className="font-bold">{formatINR(project.goalAmountInr)}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-8 border-t border-border pt-6">
                      <div>
                        <div className="text-2xl font-bold">{project.believersCount.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">Believers</div>
                      </div>
                      <div>
                        <div className={`text-2xl font-bold ${isUrgent ? "text-red-500" : ""}`}>
                          {project.status === "made-real" ? "Done ✓" : project.daysLeft}
                        </div>
                        <div className={`text-sm ${isUrgent ? "text-red-400 font-semibold" : "text-muted-foreground"}`}>
                          {project.status === "made-real" ? "Made real" : isUrgent ? "Days left — hurry!" : "Days left"}
                        </div>
                      </div>
                    </div>

                    <Button
                      size="lg"
                      onClick={openWaitlist}
                      className="w-full h-14 text-lg font-bold rounded-xl shadow-md hover:shadow-lg transition-all"
                    >
                      Fuel it!
                    </Button>
                  </div>

                  {/* Creator Card — no Contact button */}
                  <div className="bg-[#F8F9FA] rounded-2xl p-6 border border-border">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-14 h-14 border-2 border-white shadow-sm">
                        <AvatarImage src={project.creator.avatarUrl} />
                        <AvatarFallback>{project.creator.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-bold text-base flex items-center gap-1">
                          {project.creator.name}
                          {project.creator.isVerified && <ShieldCheck className="w-4 h-4 text-primary" />}
                        </div>
                        <div className="text-xs text-muted-foreground">{project.creator.city}</div>
                        <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                          {project.creator.bio}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Rewards */}
                  <div>
                    <h3 className="font-bold text-xl mb-4">Rewards</h3>
                    <div className="space-y-4">
                      {project.rewardTiers.map((tier, idx) => {
                        const isSoldOut = tier.max !== null && tier.claimed >= tier.max;

                        return (
                          <div
                            key={idx}
                            className={`border ${isSoldOut ? "border-border/50 bg-muted/30 opacity-70" : "border-border bg-card hover:border-primary/50 hover:shadow-md"} rounded-2xl p-5 transition-all cursor-pointer`}
                            onClick={isSoldOut ? undefined : openWaitlist}
                          >
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-bold text-lg">{tier.title}</h4>
                              <div className="font-bold text-primary text-lg">{formatINR(tier.amountInr)}</div>
                            </div>
                            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                              {tier.description}
                            </p>

                            <div className="flex flex-col gap-2 text-xs font-medium text-muted-foreground bg-[#F8F9FA] p-3 rounded-xl mb-4">
                              <div className="flex items-center gap-2">
                                <span className="uppercase tracking-wider">Estimated Delivery:</span>
                                <span className="text-foreground">{tier.estimatedDelivery}</span>
                              </div>
                            </div>

                            <div className="flex justify-between items-center text-sm">
                              <span className="font-medium">
                                {tier.claimed} claimed
                                {tier.max && ` · ${tier.max - tier.claimed} left`}
                              </span>
                            </div>

                            <Button
                              variant={isSoldOut ? "secondary" : "default"}
                              className="w-full mt-4 rounded-xl"
                              disabled={isSoldOut}
                            >
                              {isSoldOut ? "Sold Out" : "Select this reward"}
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>
              </div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
