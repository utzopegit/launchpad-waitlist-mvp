interface TrustScoreProps {
  score: number | null;
  className?: string;
}

export function TrustScore({ score, className = "" }: TrustScoreProps) {
  if (score === null) return null;

  let colorClass = "bg-green-500 text-green-950";
  if (score < 70) colorClass = "bg-yellow-500 text-yellow-950";
  if (score < 50) colorClass = "bg-red-500 text-red-950";

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <div className="flex items-center justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground mb-1">
        <span>Trust Score</span>
        <span className="font-bold text-foreground">{score}/100</span>
      </div>
      <div className="w-full bg-secondary h-1.5 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${colorClass.split(" ")[0]}`} 
          style={{ width: `${score}%` }} 
        />
      </div>
    </div>
  );
}
