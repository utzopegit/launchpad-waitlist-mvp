import { useSearch, useLocation, Link } from "wouter";
import { Category } from "@/data/projects";

const CATEGORIES: (Category | "Discover")[] = [
  "Consumer Products",
  "Technology",
  "Games",
  "Video Content",
  "Music",
  "Art",
  "Crafts",
  "Written Content",
  "Student Projects",
  "Discover",
];

export function CategoryNav() {
  const [location] = useLocation();
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const activeCategory = searchParams.get("category") || null;
  const onExplorePage = location.startsWith("/explore");

  return (
    <div className="w-full border-b border-border/40 bg-background/95 backdrop-blur-sm sticky top-14 z-40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center py-2 gap-0 flex-wrap">
          {CATEGORIES.map((cat) => {
            const isDiscover = cat === "Discover";
            const isActive = onExplorePage && (
              isDiscover ? activeCategory === null : activeCategory === cat
            );
            const href = isDiscover
              ? "/explore"
              : `/explore?category=${encodeURIComponent(cat)}`;

            return (
              <div key={cat} className="flex items-center">
                {isDiscover && (
                  <div className="h-3.5 w-px bg-border mx-3 hidden sm:block" />
                )}
                <Link
                  href={href}
                  className={`relative px-3 py-1.5 text-xs tracking-wide transition-colors duration-150 whitespace-nowrap ${
                    isActive
                      ? "text-foreground font-semibold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {cat}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-foreground rounded-t-sm" />
                  )}
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
