import { useWaitlist } from "@/contexts/WaitlistContext";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const waitlistSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  role: z.enum(["believer", "creator", "both"], {
    required_error: "Please select how you want to join.",
  }),
  city: z.string().optional(),
});

type WaitlistFormValues = z.infer<typeof waitlistSchema>;

export function WaitlistModal() {
  const { isOpen, closeWaitlist } = useWaitlist();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<WaitlistFormValues>({
    resolver: zodResolver(waitlistSchema),
    defaultValues: {
      name: "",
      email: "",
      role: undefined,
      city: "",
    },
  });

  const onSubmit = (data: WaitlistFormValues) => {
    // Save to localStorage
    const existing = JSON.parse(localStorage.getItem('launchpad_waitlist') || '[]');
    existing.push({ ...data, timestamp: new Date().toISOString() });
    localStorage.setItem('launchpad_waitlist', JSON.stringify(existing));
    
    setIsSubmitted(true);
    setTimeout(() => {
      closeWaitlist();
      setTimeout(() => {
        setIsSubmitted(false);
        form.reset();
      }, 500);
    }, 3000);
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) closeWaitlist();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md rounded-2xl overflow-hidden p-0 gap-0">
        <AnimatePresence mode="wait">
          {!isSubmitted ? (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-6 sm:p-8"
            >
              <DialogHeader className="mb-6">
                <DialogTitle className="text-2xl font-bold font-sans">You're early.</DialogTitle>
                <DialogDescription className="text-base">
                  Launchpad is opening soon. Tell us who you are, and you'll be among the first in the room.
                </DialogDescription>
              </DialogHeader>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Arjun Reddy" {...field} className="rounded-xl" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="arjun@example.com" {...field} className="rounded-xl" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>I'm here as a...</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="believer" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Believer (I want to support ideas)</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="creator" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Creator (I have an idea to build)</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="both" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">Both</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City <span className="text-muted-foreground font-normal">(Optional)</span></FormLabel>
                        <FormControl>
                          <Input placeholder="Bengaluru" {...field} className="rounded-xl" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full rounded-xl py-6 text-base font-semibold mt-2">
                    Join the Waitlist
                  </Button>
                </form>
              </Form>
            </motion.div>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-4 h-[500px]"
            >
              <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                <CheckCircle2 className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold font-sans">You're in.</h3>
              <p className="text-muted-foreground">
                We'll reach out when Launchpad opens its doors — and you'll be among the first.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
