import { Project } from "@/data/projects";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ProgressBar } from "./ProgressBar";
import { formatINR } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck } from "lucide-react";

interface ProjectCardProps {
  project: Project;
  index?: number;
  compact?: boolean;
}

function trustBadgeClass(score: number): string {
  if (score >= 85) return "bg-green-500 text-white";
  if (score >= 70) return "bg-blue-500 text-white";
  if (score >= 55) return "bg-amber-400 text-white";
  return "bg-orange-500 text-white";
}

export function ProjectCard({ project, index = 0, compact = false }: ProjectCardProps) {
  const percentage = Math.round((project.fuelledAmountInr / project.goalAmountInr) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      className="h-full"
    >
      <Link href={`/projects/${project.slug}`} className="h-full block">
        <div className="group h-full flex flex-col bg-card rounded-2xl border border-card-border overflow-hidden shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-pointer">

          {/* Thumbnail */}
          <div className={`relative w-full overflow-hidden bg-muted ${compact ? "flex-1 min-h-0" : "aspect-[16/9]"}`}>
            <img
              src={project.coverImageUrl}
              alt={project.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              loading="lazy"
            />

            {/* Category badge — bottom left */}
            <div className="absolute bottom-2.5 left-2.5">
              <Badge variant="secondary" className="bg-background/90 backdrop-blur-sm text-foreground shadow-sm text-[10px] px-2 py-0.5">
                {project.category}
              </Badge>
            </div>

            {/* Made Real badge — top left */}
            {project.status === "made-real" && (
              <div className="absolute top-2.5 left-2.5">
                <Badge className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm border-none text-[10px] px-2 py-0.5">
                  Made Real!
                </Badge>
              </div>
            )}

            {/* Trust score — top right */}
            {project.trustScore !== null && (
              <div className={`absolute top-2.5 right-2.5 flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full shadow ${trustBadgeClass(project.trustScore)}`}>
                <ShieldCheck className="h-2.5 w-2.5" />
                {project.trustScore}
              </div>
            )}
          </div>

          {/* Body */}
          <div className={`flex flex-col ${compact ? "p-3" : "p-5 flex-grow"}`}>
            <h3 className={`font-bold leading-tight mb-1 line-clamp-2 group-hover:text-primary transition-colors ${compact ? "text-sm" : "text-base"}`}>
              {project.title}
            </h3>
            {!compact && (
              <p className="text-muted-foreground text-sm line-clamp-2 mb-3 flex-grow">
                {project.tagline}
              </p>
            )}

            <div className="mt-auto space-y-2.5">
              {!compact && (
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={project.creator.avatarUrl} />
                    <AvatarFallback>{project.creator.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground truncate">by {project.creator.name}</span>
                </div>
              )}

              <div className="space-y-1">
                <ProgressBar fuelledAmountInr={project.fuelledAmountInr} goalAmountInr={project.goalAmountInr} />
                <div className="flex justify-between text-xs font-medium">
                  <span>
                    <span className="text-primary">{formatINR(project.fuelledAmountInr)}</span>
                    <span className="text-muted-foreground"> / {formatINR(project.goalAmountInr)}</span>
                  </span>
                  <span className="text-muted-foreground">{percentage}%</span>
                </div>
              </div>

              <div className="flex justify-between text-xs text-muted-foreground border-t border-border pt-2">
                <span className="font-medium text-foreground">
                  {project.believersCount.toLocaleString()} believers
                </span>
                <span className={
                  project.status === "made-real"
                    ? "text-green-600 font-semibold"
                    : project.daysLeft <= 5
                    ? "text-red-500 font-semibold"
                    : ""
                }>
                  {project.status === "made-real" ? "Funded ✓" : `${project.daysLeft}d left`}
                </span>
              </div>
            </div>
          </div>

        </div>
      </Link>
    </motion.div>
  );
}
