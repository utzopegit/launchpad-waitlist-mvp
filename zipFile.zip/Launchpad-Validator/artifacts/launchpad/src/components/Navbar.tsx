import { Link } from "wouter";
import { useWaitlist } from "@/contexts/WaitlistContext";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const { openWaitlist } = useWaitlist();

  return (
    <nav className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur-md border-b border-border/40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-14 grid grid-cols-3 items-center">

        {/* Left — logo icon */}
        <div className="flex items-center">
          <Link href="/" className="flex items-center hover:opacity-90 transition-opacity">
            <img src="/logo.jpg" alt="Launchpad" className="h-8 w-8 object-contain rounded-md" />
          </Link>
        </div>

        {/* Center — LAUNCHPAD wordmark */}
        <div className="flex justify-center">
          <Link href="/" className="hover:opacity-85 transition-opacity">
            <span
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 900,
                fontSize: "1.35rem",
                letterSpacing: "0.18em",
                color: "#70DEFE",
                WebkitTextStroke: "2.5px #111",
                paintOrder: "stroke fill",
                textTransform: "uppercase",
                display: "block",
                lineHeight: 1,
              }}
            >
              Launchpad
            </span>
          </Link>
        </div>

        {/* Right — buttons */}
        <div className="flex items-center justify-end gap-3">
          <Button variant="ghost" onClick={openWaitlist} className="hidden sm:inline-flex text-sm h-8 px-3">
            Log in
          </Button>
          <Button onClick={openWaitlist} className="font-medium rounded-full text-sm h-8 px-4 shadow-sm hover:shadow-md transition-all">
            Start a Project
          </Button>
        </div>

      </div>
    </nav>
  );
}
