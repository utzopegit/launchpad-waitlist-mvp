import { Link } from "wouter";
import { useWaitlist } from "@/contexts/WaitlistContext";
import { Button } from "@/components/ui/button";

export function Footer() {
  const { openWaitlist } = useWaitlist();

  return (
    <footer className="bg-background border-t border-border/40 py-12 md:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">

        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 mb-2">
            <img src="/logo.jpg" alt="Launchpad" className="h-7 w-7 object-contain rounded-md" />
            <span className="font-bold text-xl tracking-tight">Launchpad</span>
          </div>
          <p className="text-muted-foreground text-sm max-w-xs leading-relaxed">
            India's space for creators, innovators, and dreamers —{" "}
            <strong className="text-foreground">and the people who believe in them.</strong>
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-8 sm:gap-16">
          <div className="flex flex-col gap-3">
            <h4 className="font-semibold text-sm uppercase tracking-wider">Navigate</h4>
            <Link href="/explore" className="text-muted-foreground hover:text-primary transition-colors text-sm">
              Explore Projects
            </Link>
            <button onClick={openWaitlist} className="text-muted-foreground hover:text-primary transition-colors text-sm text-left">
              Join Waitlist
            </button>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="font-semibold text-sm uppercase tracking-wider">Get Early Access</h4>
            <Button onClick={openWaitlist} className="rounded-full text-sm h-9 px-5">
              Join the Waitlist
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-border/40 text-center md:text-left text-sm text-muted-foreground flex flex-col md:flex-row justify-between items-center gap-4">
        <p>© 2026 Launchpad. Made with ❤️ in India 🇮🇳</p>
        <div className="flex gap-4">
          <span className="cursor-pointer hover:text-foreground">Terms</span>
          <span className="cursor-pointer hover:text-foreground">Privacy</span>
        </div>
      </div>
    </footer>
  );
}
