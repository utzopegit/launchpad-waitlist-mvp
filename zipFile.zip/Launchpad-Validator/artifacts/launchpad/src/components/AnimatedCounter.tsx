import { motion, useInView } from "framer-motion";
import { useEffect, useRef, useState } from "react";

interface AnimatedCounterProps {
  value: number;
  format?: (val: number) => string;
  duration?: number;
  className?: string;
}

export function AnimatedCounter({ value, format = (v) => v.toString(), duration = 2, className }: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const stepTime = Math.abs(Math.floor((duration * 1000) / value)) || 10;
      let timer: ReturnType<typeof setInterval>;
      
      const steps = 60; // 60fps
      const increment = value / steps;
      let currentStep = 0;

      timer = setInterval(() => {
        currentStep++;
        const nextValue = Math.min(Math.round(increment * currentStep), value);
        setCurrent(nextValue);
        
        if (currentStep >= steps) {
          clearInterval(timer);
          setCurrent(value);
        }
      }, (duration * 1000) / steps);

      return () => clearInterval(timer);
    }
  }, [value, duration, isInView]);

  return (
    <span ref={ref} className={className}>
      {format(current)}
    </span>
  );
}
