import { motion } from "framer-motion";

interface ProgressBarProps {
  fuelledAmountInr: number;
  goalAmountInr: number;
  className?: string;
  barClassName?: string;
}

export function ProgressBar({ fuelledAmountInr, goalAmountInr, className = "", barClassName = "" }: ProgressBarProps) {
  // Visual bar is capped at 100% width, but percentage text can exceed 100%
  const visualPct = Math.min(Math.round((fuelledAmountInr / goalAmountInr) * 100), 100);

  return (
    <div className={`w-full bg-secondary overflow-hidden rounded-full h-2 ${className}`}>
      <motion.div
        className={`h-full bg-primary rounded-full ${barClassName}`}
        initial={{ width: 0 }}
        whileInView={{ width: `${visualPct}%` }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
      />
    </div>
  );
}
