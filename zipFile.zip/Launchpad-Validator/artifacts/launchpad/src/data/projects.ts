export type Category = 'Consumer Products' | 'Technology' | 'Games' | 'Video Content' | 'Music' | 'Art' | 'Crafts' | 'Written Content' | 'Student Projects';

export interface RewardTier {
  title: string;
  amountInr: number;
  description: string;
  estimatedDelivery: string;
  isLimited: boolean;
  claimed: number;
  max: number | null;
}

export interface Project {
  slug: string;
  title: string;
  tagline: string;
  category: Category;
  tags: string[];
  location: string;
  coverImageUrl: string;
  videoUrl?: string;
  goalAmountInr: number;
  fuelledAmountInr: number;
  believersCount: number;
  daysLeft: number;
  status: 'live' | 'made-real';
  trustScore: number | null;
  creator: {
    name: string;
    avatarUrl: string;
    city: string;
    isVerified: boolean;
    bio: string;
  };
  story: string;
  risks: string;
  rewardTiers: RewardTier[];
}

export const projects: Project[] = [
  {
    slug: "kadam-sustainable-sneakers",
    title: "KADAM — Sneakers for Conscious Feet",
    tagline: "Sustainable sneaker brand made from upcycled materials.",
    category: "Consumer Products",
    tags: ["Sustainable", "Fashion", "Footwear"],
    location: "Pune, India",
    coverImageUrl: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1800000,
    fuelledAmountInr: 1404000,
    believersCount: 342,
    daysLeft: 12,
    status: "live",
    trustScore: 85,
    creator: {
      name: "Priya Sharma",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Priya",
      city: "Pune",
      isVerified: true,
      bio: "Designer turned sustainability advocate."
    },
    story: "KADAM was born from a simple idea: shoes shouldn't cost the earth. We've spent 2 years researching materials to create a sneaker that is 100% upcycled yet incredibly durable and stylish.",
    risks: "Supply chain delays could impact delivery times, but we have partnered with multiple vendors to mitigate this.",
    rewardTiers: [
      { title: "Early Bird Sneaker", amountInr: 2500, description: "One pair of KADAM sneakers.", estimatedDelivery: "Oct 2026", isLimited: true, claimed: 100, max: 200 },
      { title: "Two Pairs Pack", amountInr: 4500, description: "Two pairs in any color.", estimatedDelivery: "Oct 2026", isLimited: false, claimed: 45, max: null }
    ]
  },
  {
    slug: "suryakiran-solar-kit",
    title: "SuryaKiran Irrigation Kit",
    tagline: "Solar-powered irrigation for small farmers.",
    category: "Consumer Products",
    tags: ["Agriculture", "Solar", "Tech"],
    location: "Nagpur, India",
    coverImageUrl: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1200000,
    fuelledAmountInr: 408000,
    believersCount: 89,
    daysLeft: 24,
    status: "live",
    trustScore: 92,
    creator: {
      name: "Anand Patil",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Anand",
      city: "Nagpur",
      isVerified: true,
      bio: "Engineer with a passion for rural tech."
    },
    story: "Farmers face huge challenges with unreliable power. SuryaKiran provides an affordable, portable solar kit to keep water flowing.",
    risks: "Weather dependencies during manufacturing, but designs are finalized.",
    rewardTiers: [
      { title: "Supporter Tier", amountInr: 500, description: "Thank you note and digital updates.", estimatedDelivery: "Aug 2026", isLimited: false, claimed: 89, max: null },
      { title: "Donate a Kit", amountInr: 15000, description: "Donate one kit to a farmer.", estimatedDelivery: "Dec 2026", isLimited: false, claimed: 12, max: null }
    ]
  },
  {
    slug: "chargmate-ev-accessory",
    title: "ChargMate — India's Smart EV Companion",
    tagline: "Portable EV charging accessory that fits in your trunk.",
    category: "Technology",
    tags: ["EV", "Hardware", "Smart"],
    location: "Bengaluru, India",
    coverImageUrl: "https://images.unsplash.com/photo-1593941707882-a5bba14938cb?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 2500000,
    fuelledAmountInr: 1375000,
    believersCount: 210,
    daysLeft: 18,
    status: "live",
    trustScore: 78,
    creator: {
      name: "Rahul Nair",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Rahul",
      city: "Bengaluru",
      isVerified: true,
      bio: "Automotive engineer building the future of mobility."
    },
    story: "Range anxiety is real. ChargMate gives you that extra 20km to reach home or a station safely, powered by smart battery management.",
    risks: "Certification processes for battery hardware.",
    rewardTiers: [
      { title: "ChargMate Pro", amountInr: 12000, description: "One ChargMate unit.", estimatedDelivery: "Jan 2027", isLimited: true, claimed: 50, max: 100 }
    ]
  },
  {
    slug: "ghar-smart-hub",
    title: "Ghar Smart Hub",
    tagline: "Smart home device designed for Indian apartments.",
    category: "Technology",
    tags: ["Smart Home", "IoT"],
    location: "Hyderabad, India",
    coverImageUrl: "https://images.unsplash.com/photo-1558002038-1055907df827?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1500000,
    fuelledAmountInr: 1560000,
    believersCount: 487,
    daysLeft: 0,
    status: "made-real",
    trustScore: 95,
    creator: {
      name: "Ghar Tech",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Ghar",
      city: "Hyderabad",
      isVerified: true,
      bio: "Startup focused on contextual smart homes."
    },
    story: "Power cuts? Inverter issues? Ghar Hub integrates perfectly with Indian home setups to keep your smart devices running seamlessly.",
    risks: "None. We are in production.",
    rewardTiers: [
      { title: "Ghar Hub", amountInr: 4500, description: "One Ghar Hub device.", estimatedDelivery: "Sep 2026", isLimited: false, claimed: 487, max: null }
    ]
  },
  {
    slug: "dharti-rpg",
    title: "Dharti — A Tabletop RPG of Ancient India",
    tagline: "Explore ancient myths and legends in this immersive RPG.",
    category: "Games",
    tags: ["Tabletop", "RPG", "Mythology"],
    location: "Bengaluru, India",
    coverImageUrl: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffaed?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 800000,
    fuelledAmountInr: 736000,
    believersCount: 156,
    daysLeft: 5,
    status: "live",
    trustScore: 88,
    creator: {
      name: "Katha Studios",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Katha",
      city: "Bengaluru",
      isVerified: true,
      bio: "Indie game designers creating culturally rich experiences."
    },
    story: "Dharti brings the epics to your table. Complete with rulebooks, beautifully illustrated maps, and custom dice.",
    risks: "Printing delays for high-quality hardcovers.",
    rewardTiers: [
      { title: "Core Rulebook", amountInr: 1800, description: "Hardcover Dharti Core Rulebook.", estimatedDelivery: "Nov 2026", isLimited: false, claimed: 100, max: null }
    ]
  },
  {
    slug: "cricket-strategos",
    title: "Cricket Strategos",
    tagline: "Deep mobile strategy game for hardcore cricket fans.",
    category: "Games",
    tags: ["Mobile Game", "Sports", "Strategy"],
    location: "Mumbai, India",
    coverImageUrl: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 600000,
    fuelledAmountInr: 72000,
    believersCount: 45,
    daysLeft: 22,
    status: "live",
    trustScore: null,
    creator: {
      name: "Wicket Games",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Wicket",
      city: "Mumbai",
      isVerified: false,
      bio: "Two devs obsessed with cricket analytics."
    },
    story: "We wanted a game that wasn't just about timing a swipe, but managing a team like a real captain.",
    risks: "Game balancing and matchmaking scaling.",
    rewardTiers: [
      { title: "Beta Access", amountInr: 500, description: "Early access to the beta and exclusive in-game badge.", estimatedDelivery: "Jul 2026", isLimited: false, claimed: 45, max: null }
    ]
  },
  {
    slug: "andheri-western",
    title: "Andheri Western — An Indie Hindi Film",
    tagline: "A neo-western set in the Mumbai local train network.",
    category: "Video Content",
    tags: ["Film", "Indie", "Cinema"],
    location: "Mumbai, India",
    coverImageUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 4500000,
    fuelledAmountInr: 3015000,
    believersCount: 891,
    daysLeft: 9,
    status: "live",
    trustScore: 90,
    creator: {
      name: "Vikram Motwane",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Vikram",
      city: "Mumbai",
      isVerified: true,
      bio: "Independent filmmaker with 2 award-winning shorts."
    },
    story: "A story of ambition, hustle, and the chaotic beauty of Mumbai's lifelines.",
    risks: "Filming permissions in public spaces.",
    rewardTiers: [
      { title: "Digital Premiere", amountInr: 1000, description: "Ticket to the digital premiere.", estimatedDelivery: "Mar 2027", isLimited: false, claimed: 500, max: null }
    ]
  },
  {
    slug: "haath-ka-hunar",
    title: "Haath Ka Hunar",
    tagline: "Docu-series exploring India's forgotten craft artisans.",
    category: "Video Content",
    tags: ["Documentary", "Culture"],
    location: "Jaipur, India",
    coverImageUrl: "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 2000000,
    fuelledAmountInr: 1760000,
    believersCount: 423,
    daysLeft: 14,
    status: "live",
    trustScore: 82,
    creator: {
      name: "Srishti Films",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Srishti",
      city: "Jaipur",
      isVerified: true,
      bio: "Documenting the undocumented."
    },
    story: "From weaving to metalwork, we capture the stories of artisans keeping traditions alive.",
    risks: "Travel logistics across remote villages.",
    rewardTiers: [
      { title: "Credit Mention", amountInr: 2500, description: "Your name in the series credits.", estimatedDelivery: "Dec 2026", isLimited: false, claimed: 150, max: null }
    ]
  },
  {
    slug: "sangam-carnatic-album",
    title: "Sangam — A Carnatic Fusion Album",
    tagline: "Classical Carnatic vocals meet modern jazz arrangements.",
    category: "Music",
    tags: ["Music", "Fusion", "Classical"],
    location: "Chennai, India",
    coverImageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 500000,
    fuelledAmountInr: 355000,
    believersCount: 234,
    daysLeft: 8,
    status: "live",
    trustScore: 75,
    creator: {
      name: "Aditi Iyer",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Aditi",
      city: "Chennai",
      isVerified: true,
      bio: "Vocalist exploring the boundaries of genre."
    },
    story: "Sangam is a 6-track EP that bridges centuries of tradition with contemporary soundscapes.",
    risks: "Studio availability and post-production timelines.",
    rewardTiers: [
      { title: "Vinyl Edition", amountInr: 2000, description: "Exclusive Sangam Vinyl.", estimatedDelivery: "Sep 2026", isLimited: true, claimed: 100, max: 300 }
    ]
  },
  {
    slug: "kinara-debut-ep",
    title: "Kinara — Debut EP",
    tagline: "Folk meets indie rock on our very first record.",
    category: "Music",
    tags: ["Indie", "Rock", "Band"],
    location: "Delhi, India",
    coverImageUrl: "https://images.unsplash.com/photo-1493225457224-aa8cecb2f5b4?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 350000,
    fuelledAmountInr: 157500,
    believersCount: 112,
    daysLeft: 20,
    status: "live",
    trustScore: 68,
    creator: {
      name: "Kinara",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Kinara",
      city: "Delhi",
      isVerified: false,
      bio: "4-piece band trying to make some noise."
    },
    story: "We've been playing college gigs for years. It's time to record our originals.",
    risks: "First time managing a full production.",
    rewardTiers: [
      { title: "Digital EP + Merch", amountInr: 800, description: "Digital download and band tee.", estimatedDelivery: "Nov 2026", isLimited: false, claimed: 50, max: null }
    ]
  },
  {
    slug: "rang-aur-roshni",
    title: "Rang aur Roshni",
    tagline: "Transforming Delhi's underpasses into vibrant art galleries.",
    category: "Art",
    tags: ["Public Art", "Mural", "Community"],
    location: "Delhi, India",
    coverImageUrl: "https://images.unsplash.com/photo-1499803270242-467f73115822?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1400000,
    fuelledAmountInr: 868000,
    believersCount: 308,
    daysLeft: 16,
    status: "live",
    trustScore: 91,
    creator: {
      name: "Delhi Street Art",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=DSA",
      city: "Delhi",
      isVerified: true,
      bio: "Collective bringing art to the streets."
    },
    story: "Grey concrete walls shouldn't be the norm. We're painting 5 massive underpasses with stories of local heroes.",
    risks: "City permissions are secured, but weather could delay painting.",
    rewardTiers: [
      { title: "Art Print", amountInr: 1500, description: "A5 print of the mural concepts.", estimatedDelivery: "Oct 2026", isLimited: false, claimed: 200, max: null }
    ]
  },
  {
    slug: "bharat-illustration-series",
    title: "Bharat — A Contemporary Illustration Series",
    tagline: "100 illustrations capturing the soul of modern India.",
    category: "Art",
    tags: ["Illustration", "Book", "Design"],
    location: "Kolkata, India",
    coverImageUrl: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 400000,
    fuelledAmountInr: 416000,
    believersCount: 178,
    daysLeft: 0,
    status: "made-real",
    trustScore: 89,
    creator: {
      name: "Rohan Das",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Rohan",
      city: "Kolkata",
      isVerified: true,
      bio: "Visual artist fascinated by everyday chaos."
    },
    story: "A visual journey from street food stalls to tech parks, compiled in a stunning coffee table book.",
    risks: "None. Off to the printers.",
    rewardTiers: [
      { title: "Coffee Table Book", amountInr: 2500, description: "Hardcover illustration book.", estimatedDelivery: "Aug 2026", isLimited: false, claimed: 178, max: null }
    ]
  },
  {
    slug: "baandhni-collective",
    title: "Baandhni Collective",
    tagline: "Reviving handloom weaving in Kutch through fair-trade.",
    category: "Crafts",
    tags: ["Handloom", "Textiles", "Social"],
    location: "Kutch, India",
    coverImageUrl: "https://images.unsplash.com/photo-1558171811-a036f5d7e5d4?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1000000,
    fuelledAmountInr: 380000,
    believersCount: 134,
    daysLeft: 28,
    status: "live",
    trustScore: 84,
    creator: {
      name: "Meera Patel",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Meera",
      city: "Bhuj",
      isVerified: true,
      bio: "Working with artisans to sustain their craft."
    },
    story: "Fast fashion is erasing heritage. The Baandhni Collective provides fair wages to 50 weavers to create timeless pieces.",
    risks: "Logistics and shipping from remote areas.",
    rewardTiers: [
      { title: "Handwoven Stole", amountInr: 3000, description: "Beautiful handwoven stole.", estimatedDelivery: "Nov 2026", isLimited: false, claimed: 80, max: null }
    ]
  },
  {
    slug: "mitti-pottery-studio",
    title: "Mitti — Artisanal Pottery Studio",
    tagline: "Bringing back slow, traditional ceramic techniques.",
    category: "Crafts",
    tags: ["Ceramics", "Pottery", "Studio"],
    location: "Goa, India",
    coverImageUrl: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 700000,
    fuelledAmountInr: 567000,
    believersCount: 267,
    daysLeft: 7,
    status: "live",
    trustScore: 86,
    creator: {
      name: "Anil & Tara",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Tara",
      city: "Goa",
      isVerified: true,
      bio: "Duo finding peace in clay."
    },
    story: "We're setting up a community kiln to teach and practice slow pottery.",
    risks: "Kiln construction delays.",
    rewardTiers: [
      { title: "Mitti Mug Set", amountInr: 1800, description: "Set of 2 handcrafted mugs.", estimatedDelivery: "Oct 2026", isLimited: false, claimed: 150, max: null }
    ]
  },
  {
    slug: "awaaz-audiobook",
    title: "Awaaz — Regional Language Audiobook Platform",
    tagline: "Stories in 8 Indian languages, recorded by voice artists.",
    category: "Written Content",
    tags: ["Audio", "Literature", "App"],
    location: "Chennai, India",
    coverImageUrl: "https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 3000000,
    fuelledAmountInr: 720000,
    believersCount: 567,
    daysLeft: 25,
    status: "live",
    trustScore: 77,
    creator: {
      name: "Awaaz Media",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Awaaz",
      city: "Chennai",
      isVerified: true,
      bio: "Audio tech startup."
    },
    story: "Millions of stories exist in Tamil, Bengali, Marathi, and more. Awaaz brings them to your ears.",
    risks: "Content licensing negotiations.",
    rewardTiers: [
      { title: "Lifetime Subscription", amountInr: 5000, description: "Lifetime access to Awaaz.", estimatedDelivery: "Jan 2027", isLimited: true, claimed: 200, max: 500 }
    ]
  },
  {
    slug: "naksha-graphic-novel",
    title: "Naksha — A Graphic Novel Series",
    tagline: "A 3-volume graphic novel exploring the history of partition.",
    category: "Written Content",
    tags: ["Comics", "History", "Books"],
    location: "Delhi, India",
    coverImageUrl: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 900000,
    fuelledAmountInr: 657000,
    believersCount: 189,
    daysLeft: 11,
    status: "live",
    trustScore: 93,
    creator: {
      name: "Zoya Khan",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Zoya",
      city: "Delhi",
      isVerified: true,
      bio: "Illustrator and storyteller."
    },
    story: "Told through the eyes of two families, Naksha is a heavily researched visual narrative of a defining moment in history.",
    risks: "Illustration is time-intensive, but Vol 1 is 80% complete.",
    rewardTiers: [
      { title: "Volume 1 Hardcover", amountInr: 1200, description: "Signed hardcover of Volume 1.", estimatedDelivery: "Dec 2026", isLimited: false, claimed: 150, max: null }
    ]
  },
  {
    slug: "bvp-robotics",
    title: "BVP Roboclub — National Championship Push",
    tagline: "Help our college robotics team build our best bot yet.",
    category: "Student Projects",
    tags: ["Robotics", "Engineering", "College"],
    location: "Pune, India",
    coverImageUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 400000,
    fuelledAmountInr: 220000,
    believersCount: 98,
    daysLeft: 15,
    status: "live",
    trustScore: 63,
    creator: {
      name: "BVP Roboclub",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=BVP",
      city: "Pune",
      isVerified: false,
      bio: "Undergrad engineers."
    },
    story: "We've qualified for the nationals! We just need funds for better motors and sensors to compete with the top tier.",
    risks: "Competition timelines are strict.",
    rewardTiers: [
      { title: "Name on Bot", amountInr: 1000, description: "Your name engraved on our robot.", estimatedDelivery: "Sep 2026", isLimited: false, claimed: 50, max: null }
    ]
  },
  {
    slug: "hara-campus-initiative",
    title: "Hara — Campus Zero-Waste Initiative",
    tagline: "Setting up a complete composting and recycling system.",
    category: "Student Projects",
    tags: ["Environment", "Campus"],
    location: "Manipal, India",
    coverImageUrl: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 200000,
    fuelledAmountInr: 208000,
    believersCount: 234,
    daysLeft: 0,
    status: "made-real",
    trustScore: 88,
    creator: {
      name: "EcoClub Manipal",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Eco",
      city: "Manipal",
      isVerified: true,
      bio: "Student-led green initiative."
    },
    story: "We successfully funded the equipment. Our campus will be zero-waste by next semester!",
    risks: "None.",
    rewardTiers: [
      { title: "Supporter", amountInr: 500, description: "Updates on our progress.", estimatedDelivery: "Aug 2026", isLimited: false, claimed: 200, max: null }
    ]
  },
  {
    slug: "indus-os-custom-rom",
    title: "Indus OS — A Privacy First Custom ROM",
    tagline: "An open-source mobile OS tailored for privacy.",
    category: "Technology",
    tags: ["Open Source", "Software", "Privacy"],
    location: "Bengaluru, India",
    coverImageUrl: "https://images.unsplash.com/photo-1526498460520-4c246339dccb?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 800000,
    fuelledAmountInr: 560000,
    believersCount: 312,
    daysLeft: 10,
    status: "live",
    trustScore: 89,
    creator: {
      name: "Dev Collective",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=DevCo",
      city: "Bengaluru",
      isVerified: true,
      bio: "Privacy advocates and kernel hackers."
    },
    story: "Take back control of your phone. Indus OS strips out the trackers while maintaining app compatibility.",
    risks: "Device compatibility requires constant maintenance.",
    rewardTiers: [
      { title: "Early Build Access", amountInr: 1000, description: "Access to nightly builds.", estimatedDelivery: "Oct 2026", isLimited: false, claimed: 250, max: null }
    ]
  },
  {
    slug: "woven-tales-exhibition",
    title: "Woven Tales — Textile Art Exhibition",
    tagline: "An immersive gallery experience exploring Indian textiles.",
    category: "Art",
    tags: ["Exhibition", "Gallery", "Textiles"],
    location: "Mumbai, India",
    coverImageUrl: "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80",
    goalAmountInr: 1200000,
    fuelledAmountInr: 540000,
    believersCount: 145,
    daysLeft: 21,
    status: "live",
    trustScore: 81,
    creator: {
      name: "Kala Kendra",
      avatarUrl: "https://api.dicebear.com/7.x/personas/svg?seed=Kala",
      city: "Mumbai",
      isVerified: true,
      bio: "Art curation studio."
    },
    story: "Woven Tales is a month-long showcase of 22 textile artists from across India, in the heart of Mumbai.",
    risks: "Venue logistics and artist travel.",
    rewardTiers: [
      { title: "Opening Night Pass", amountInr: 1500, description: "Access to opening night and guided tour.", estimatedDelivery: "Feb 2027", isLimited: true, claimed: 60, max: 100 }
    ]
  }
];
